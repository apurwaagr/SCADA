# Semantic Search Playground


This project accompanies the Ingenuity Blog post https://blog.siemens.com/2023/07/build-your-own-semantic-search-with-large-language-models/

See the [Jupyter Notebook](semantic_search_playground.ipynb) for the code.

![alt text](robot_searching_documents.png "Robot searching documents")
